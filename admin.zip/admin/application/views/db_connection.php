<?php
$con=mysqli_connect("localhost", "root", "", "db_property");//localhost database connection
//$con = mysqli_connect("localhost","rsceduco_place","@siteadmin2020","rsceduco_placement");//server database connection
?>