<?php
$con=mysqli_connect("localhost", "root", "", "siteadmin");//localhost database connection
//$con = mysqli_connect("localhost","rsceduco_siteadmin","@siteadmin2020","rsceduco_siteadmin");//server database connection
?>